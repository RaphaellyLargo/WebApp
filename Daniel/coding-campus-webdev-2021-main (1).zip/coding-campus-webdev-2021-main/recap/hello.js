export function helloWorld() {
    console.log('Hello World from a module!');
}
