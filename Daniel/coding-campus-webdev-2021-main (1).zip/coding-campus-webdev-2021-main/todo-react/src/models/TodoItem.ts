export default interface TodoItem {
    id: string,
    name: string,
    completed: boolean
}