function getHelloText(name, state) {
    return "Hello " + name;
}
console.log(getHelloText('Daniel', "locked"));
